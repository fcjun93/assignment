package removeitem;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.*;

public class RemoveItem {

    public static ArrayList<Items> itemList = new ArrayList<>();
    public static Scanner scn = new Scanner(System.in);
    public static DecimalFormat df = new DecimalFormat("0.00");
    public static String[] items1 = {"breakfast combo", "lunch combo", "dinner combo", "nuggget",
        "hotdog", "burger", "coffee", "coke", "100 plus", "sprite", "mineral water"};
    public static String[] items2 = {"fried noodle", "fried rice", "chicken rice", "yee mee sup", "white rice",
        "vegetable", "taufu", "milo", "can drink", "herbal drink", "mineral water"};
    public static String[] items3 = {"fried chicken", "fried rice", "speghetti", "nuggget", "hotdog",
        "mushroom sup", "nasi lemak", "cocacola", "100 plus", "sprite", "mineral water"};
    public static String[] items4 = {"chicken chop", "fish & chip", "fries", "nuggget", "hotdog", "pasta",
        "pizza", "cocacola", "100 plus", "sprite", "mineral water"};
    public static String item;
    public static String type;
    public static Double price;

    public static void main(String[] args) {

        int choice = 0;

        System.out.println("Restaurant Name:\n===============\n1. KFC\n2. MUMMY RESTAURANT\n3. ELAINE CAFE\n4. VICKY HOUSE");
        System.out.println("");
        System.out.print("Please input the restaurant number: ");
        int res = scn.nextInt();

        switch (res) {
            case 1:
                do {
                    System.out.println("\nKFC");
                    System.out.println("1. Add new item");
                    System.out.println("2. Remove an item");
                    System.out.println("3. Promotion");
                    System.out.println("4. Exit\n");

                    System.out.print("\nSelect one option: ");
                    choice = scn.nextInt();

                    switch (choice) {
                        case 1:
                            String cont;

                            do {
                                Scanner input = new Scanner(System.in);
                                AddNewItem1();
                                System.out.println("");
                                System.out.println("Continue?(Y/N)");
                                cont = input.nextLine();

                            } while (cont.equals("y") || cont.equals("Y"));
                            break;
                        case 2:
                            System.out.println("");
                            removeItem1();
                            break;
                        case 3:
                            System.out.println("Promotion");
                            break;
                        case 4:
                            System.exit(0);
                            break;
                        default:
                            System.out.println("Invalid input.");
                            break;
                    }
                } while (choice != 4);
                break;
            case 2:
                do {
                    System.out.println("\nMUMMY RESTAURANT");
                    System.out.println("1. Add new item");
                    System.out.println("2. Remove an item");
                    System.out.println("3. Promotion");
                    System.out.println("4. Exit\n");

                    System.out.print("\nSelect one option: ");
                    choice = scn.nextInt();

                    switch (choice) {
                        case 1:
                            String cont;
                            do {
                                Scanner input = new Scanner(System.in);
                                AddNewItem2();
                                System.out.println("");
                                System.out.println("Continue?(Y/N)");
                                cont = input.nextLine();

                            } while (cont.equals("y") || cont.equals("Y"));
                            break;
                        case 2:
                            System.out.println("");
                            removeItem2();
                            break;
                        case 3:
                            System.out.println("Promotion");
                            break;
                        case 4:
                            System.exit(0);
                        default:
                            System.out.println("Invalid input.");
                            break;
                    }
                } while (choice != 4);
                break;
            case 3:
                do {
                    System.out.println("\nELAINE CAFE");
                    System.out.println("1. Add new item");
                    System.out.println("2. Remove an item");
                    System.out.println("3. Promotion");
                    System.out.println("4. Exit\n");

                    System.out.print("\nSelect one option: ");
                    choice = scn.nextInt();

                    switch (choice) {
                        case 1:
                            String cont;
                            do {
                                Scanner input = new Scanner(System.in);
                                AddNewItem3();
                                System.out.println("");
                                System.out.println("Continue?(Y/N)");
                                cont = input.nextLine();

                            } while (cont.equals("y") || cont.equals("Y"));
                            break;
                        case 2:
                            System.out.println("");
                            removeItem3();
                            break;
                        case 3:
                            System.out.println("Promotion");
                            break;
                        case 4:
                            System.exit(0);
                        default:
                            System.out.println("Invalid input.");
                            break;
                    }
                } while (choice != 4);
                break;
            case 4:
                do {
                    System.out.println("VICKY HOUSE");
                    System.out.println("\n1. Add new item");
                    System.out.println("2. Remove an item");
                    System.out.println("3. Promotion");
                    System.out.println("4. Exit\n");

                    System.out.print("\nSelect one option: ");
                    choice = scn.nextInt();

                    switch (choice) {
                        case 1:
                            String cont;
                            do {
                                Scanner input = new Scanner(System.in);
                                AddNewItem4();
                                System.out.println("");
                                System.out.println("Continue?(Y/N)");
                                cont = input.nextLine();

                            } while (cont.equals("y") || cont.equals("Y"));
                            break;
                        case 2:
                            System.out.println("");
                            removeItem4();
                            break;
                        case 3:
                            System.out.println("Promotion");
                            break;
                        case 4:
                            System.exit(0);
                        default:
                            System.out.println("Invalid input.");
                            break;

                    }
                } while (choice != 4);
                break;
            default:
                System.out.println("Please enter the valid restaurant number(1-4).");
                break;
        }
    }

    private static void AddNewItem1() {
        Scanner input = new Scanner(System.in);
        DecimalFormat decim = new DecimalFormat("0.00");

        System.out.print("\nMenu Item : ");
        item = input.nextLine();
        item = item.toLowerCase();
        System.out.print("Item Type : ");
        type = input.nextLine();
        type = type.toUpperCase();
        System.out.print("Unit Price: RM ");
        price = input.nextDouble();
        price = Double.parseDouble(decim.format(price));

        if (item.equals(items1[0])
                || item.equals(items1[1])
                || item.equals(items1[2])
                || item.equals(items1[3])
                || item.equals(items1[4])
                || item.equals(items1[5])
                || item.equals(items1[6])
                || item.equals(items1[7])
                || item.equals(items1[8])
                || item.equals(items1[9])
                || item.equals(items1[10])) {
            System.out.println("Duplicate menu item.");

        } else {
            if (price <= 0) {
                System.out.println("Please input the valid unit price.");
            } else {

                if (type.equals("DRINK") || type.equals("FOOD")) {
                    System.out.println("\nItem Added Successfully!");
                    System.out.println("==========================");
                    System.out.println("Menu Item : " + item);
                    System.out.println("Item Type : " + type);
                    System.out.println("Unit Price: RM " + decim.format(price));

                } else {
                    System.out.println("Item type must be DRINK OR FOOD");
                }
            }
        }

    }

    private static void AddNewItem2() {
        Scanner input = new Scanner(System.in);
        DecimalFormat decim = new DecimalFormat("0.00");

        System.out.print("\nMenu Item : ");
        item = input.nextLine();
        item = item.toLowerCase();
        System.out.print("Item Type : ");
        type = input.nextLine();
        type = type.toUpperCase();
        System.out.print("Unit Price: RM ");
        price = input.nextDouble();
        price = Double.parseDouble(decim.format(price));

        if (item.equals(items2[0])
                || item.equals(items2[1])
                || item.equals(items2[2])
                || item.equals(items2[3])
                || item.equals(items2[4])
                || item.equals(items2[5])
                || item.equals(items2[6])
                || item.equals(items2[7])
                || item.equals(items2[8])
                || item.equals(items2[9])
                || item.equals(items2[10])) {
            System.out.println("Duplicate menu item.");

        } else {
            if (price <= 0) {
                System.out.println("Please input the valid unit price.");
            } else {

                if (type.equals("DRINK") || type.equals("FOOD")) {
                    System.out.println("\nItem Added Successfully!");
                    System.out.println("==========================");
                    System.out.println("Menu Item : " + item);
                    System.out.println("Item Type : " + type);
                    System.out.println("Unit Price: RM " + decim.format(price));

                } else {
                    System.out.println("Item type must be DRINK OR FOOD");
                }
            }
        }

    }

    private static void AddNewItem3() {
        Scanner input = new Scanner(System.in);
        DecimalFormat decim = new DecimalFormat("0.00");

        System.out.print("\nMenu Item : ");
        item = input.nextLine();
        item = item.toLowerCase();
        System.out.print("Item Type : ");
        type = input.nextLine();
        type = type.toUpperCase();
        System.out.print("Unit Price: RM ");
        price = input.nextDouble();
        price = Double.parseDouble(decim.format(price));

        if (item.equals(items3[0])
                || item.equals(items3[1])
                || item.equals(items3[2])
                || item.equals(items3[3])
                || item.equals(items3[4])
                || item.equals(items3[5])
                || item.equals(items3[6])
                || item.equals(items3[7])
                || item.equals(items3[8])
                || item.equals(items3[9])
                || item.equals(items3[10])) {
            System.out.println("Duplicate menu item.");

        } else {
            if (price <= 0) {
                System.out.println("Please input the valid unit price.");
            } else {

                if (type.equals("DRINK") || type.equals("FOOD")) {
                    System.out.println("\nItem Added Successfully!");
                    System.out.println("==========================");
                    System.out.println("Menu Item : " + item);
                    System.out.println("Item Type : " + type);
                    System.out.println("Unit Price: RM " + decim.format(price));

                } else {
                    System.out.println("Item type must be DRINK OR FOOD");
                }
            }
        }

    }

    private static void AddNewItem4() {
        Scanner input = new Scanner(System.in);
        DecimalFormat decim = new DecimalFormat("0.00");

        System.out.print("\nMenu Item : ");
        item = input.nextLine();
        item = item.toLowerCase();
        System.out.print("Item Type : ");
        type = input.nextLine();
        type = type.toUpperCase();
        System.out.print("Unit Price: RM ");
        price = input.nextDouble();
        price = Double.parseDouble(decim.format(price));

        if (item.equals(items4[0])
                || item.equals(items4[1])
                || item.equals(items4[2])
                || item.equals(items4[3])
                || item.equals(items4[4])
                || item.equals(items4[5])
                || item.equals(items4[6])
                || item.equals(items4[7])
                || item.equals(items4[8])
                || item.equals(items4[9])
                || item.equals(items4[10])) {
            System.out.println("Duplicate menu item.");

        } else {
            if (price <= 0) {
                System.out.println("Please input the valid unit price.");
            } else {

                if (type.equals("DRINK") || type.equals("FOOD")) {
                    System.out.println("\nItem Added Successfully!");
                    System.out.println("==========================");
                    System.out.println("Menu Item : " + item);
                    System.out.println("Item Type : " + type);
                    System.out.println("Unit Price: RM " + decim.format(price));

                } else {
                    System.out.println("Item type must be DRINK OR FOOD");
                }
            }
        }

    }

    private static void removeItem4() {
        System.out.println("\t Vicky House Menu ");
        System.out.println("\t==================");
        System.out.println("Item\t\t\tPrice(RM)");
        System.out.println("****\t\t\t*********");

        Items a1 = new Items("Chicken Chop\t\t", 10.50);
        Items a2 = new Items("Fish & Chip    \t\t", 12.50);
        Items a3 = new Items("Fries   \t\t", 5.50);
        Items a4 = new Items("Nuggget       \t\t", 6.00);
        Items a5 = new Items("Hotdog        \t\t", 5.00);
        Items a6 = new Items("Pasta  \t\t\t", 9.50);
        Items a7 = new Items("Pizza    \t\t", 23.50);
        Items a8 = new Items("Cocacola      \t\t", 3.50);
        Items a9 = new Items("100 Plus      \t\t", 3.50);
        Items a10 = new Items("Sprite        \t\t", 3.50);
        Items a11 = new Items("Mineral Water \t\t", 2.00);

        itemList.add(a1);
        itemList.add(a2);
        itemList.add(a3);
        itemList.add(a4);
        itemList.add(a5);
        itemList.add(a6);
        itemList.add(a7);
        itemList.add(a8);
        itemList.add(a9);
        itemList.add(a10);
        itemList.add(a11);

        for (int k = 0; k < itemList.size(); k++) {
            System.out.println(itemList.get(k).item + " " + df.format(itemList.get(k).price));

        }
        System.out.println("");
        remove4();
    }

    private static void removeItem3() {
        System.out.println("\t Cafe Menu ");
        System.out.println("\t===========");
        System.out.println("Item\t\t\tPrice(RM)");
        System.out.println("****\t\t\t*********");

        Items a1 = new Items("Fried Chicken \t\t", 7.50);
        Items a2 = new Items("Fried Rice    \t\t", 8.00);
        Items a3 = new Items("Speghetti     \t\t", 9.30);
        Items a4 = new Items("Nuggget       \t\t", 5.00);
        Items a5 = new Items("Hotdog        \t\t", 3.00);
        Items a6 = new Items("Mushroom Sup  \t\t", 3.50);
        Items a7 = new Items("Nasi Lemak    \t\t", 4.50);
        Items a8 = new Items("Cocacola      \t\t", 3.00);
        Items a9 = new Items("100 Plus      \t\t", 3.00);
        Items a10 = new Items("Sprite        \t\t", 3.00);
        Items a11 = new Items("Mineral Water \t\t", 2.00);

        itemList.add(a1);
        itemList.add(a2);
        itemList.add(a3);
        itemList.add(a4);
        itemList.add(a5);
        itemList.add(a6);
        itemList.add(a7);
        itemList.add(a8);
        itemList.add(a9);
        itemList.add(a10);
        itemList.add(a11);

        for (int k = 0; k < itemList.size(); k++) {
            System.out.println(itemList.get(k).item + " " + df.format(itemList.get(k).price));

        }
        System.out.println("");
        remove3();
    }

    private static void removeItem2() {
        System.out.println("\t Restaurant Menu ");
        System.out.println("\t=================");
        System.out.println("Item\t\t\tPrice(RM)");
        System.out.println("****\t\t\t*********");

        Items a1 = new Items("Fried Noodle \t\t", 8.50);
        Items a2 = new Items("Fried Rice    \t\t", 7.50);
        Items a3 = new Items("Chicken Rice     \t\t", 8.50);
        Items a4 = new Items("Yee Mee Sup       \t\t", 6.00);
        Items a5 = new Items("White Rice        \t\t", 3.00);
        Items a6 = new Items("Vegetable  \t\t", 7.90);
        Items a7 = new Items("Taufu    \t\t", 6.20);
        Items a8 = new Items("Milo      \t\t", 3.50);
        Items a9 = new Items("Can Drink      \t\t", 3.00);
        Items a10 = new Items("Herbal Drink        \t\t", 2.50);
        Items a11 = new Items("Mineral Water \t\t", 2.00);

        itemList.add(a1);
        itemList.add(a2);
        itemList.add(a3);
        itemList.add(a4);
        itemList.add(a5);
        itemList.add(a6);
        itemList.add(a7);
        itemList.add(a8);
        itemList.add(a9);
        itemList.add(a10);
        itemList.add(a11);

        for (int k = 0; k < itemList.size(); k++) {
            System.out.println(itemList.get(k).item + " " + df.format(itemList.get(k).price));

        }
        System.out.println("");
        remove2();
    }

    private static void removeItem1() {
        System.out.println("\t KFC Menu ");
        System.out.println("\t==========");
        System.out.println("Item\t\t\tPrice(RM)");
        System.out.println("****\t\t\t*********");

        Items a1 = new Items("Breakfast Combo  \t", 9.50);
        Items a2 = new Items("Lunch Combo     \t", 10.60);
        Items a3 = new Items("Dinner Combo     \t", 12.30);
        Items a4 = new Items("Nuggget       \t\t", 5.90);
        Items a5 = new Items("Hotdog        \t\t", 5.90);
        Items a6 = new Items("Burger  \t\t", 6.50);
        Items a7 = new Items("Coffee   \t\t", 4.50);
        Items a8 = new Items("Coke      \t\t", 3.50);
        Items a9 = new Items("100 Plus      \t\t", 3.50);
        Items a10 = new Items("Sprite        \t\t", 3.50);
        Items a11 = new Items("Mineral Water \t\t", 2.00);

        itemList.add(a1);
        itemList.add(a2);
        itemList.add(a3);
        itemList.add(a4);
        itemList.add(a5);
        itemList.add(a6);
        itemList.add(a7);
        itemList.add(a8);
        itemList.add(a9);
        itemList.add(a10);
        itemList.add(a11);

        for (int k = 0; k < itemList.size(); k++) {
            System.out.println(itemList.get(k).item + " " + df.format(itemList.get(k).price));

        }
        System.out.println("");
        remove1();
    }

    private static void remove1() {
        System.out.print("Item Name: ");
        item = scn.nextLine();

        if (item.equalsIgnoreCase("Breakfast Combo")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Lunch Combo")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Dinner Combo")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Nugget")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Hotdog")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Burger")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Coffee")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Coke")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("100 Plus")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Sprite")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Mineral Water")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
        } else if (item.isEmpty()) {
            System.out.println("Please enter again.");
            System.out.println("");
            remove3();
        } else {
            System.out.println("The item is not available.");
        }
    }

    private static void remove2() {
        System.out.print("Item Name: ");
        item = scn.nextLine();

        if (item.equalsIgnoreCase("Fried Noodle")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Fried Rice")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Chicken Rice")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Yee Mee Sup")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("White Rice")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Vegetable")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Taufu")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Milo")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Can Drink")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Herbal Drink")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Mineral Water")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
        } else if (item.isEmpty()) {
            System.out.println("Please enter again.");
            System.out.println("");
            remove3();
        } else {
            System.out.println("The item is not available.");
        }
    }

    private static void remove3() {
        System.out.print("Item Name: ");
        item = scn.nextLine();

        if (item.equalsIgnoreCase("Fried Chicken")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Fried Rice")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Speghetti")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Nugget")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Hotdog")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Mushroom Sup")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Nasi Lemak")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Cocacola")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("100 Plus")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Sprite")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Mineral Water")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
        } else if (item.isEmpty()) {
            System.out.println("Please enter again.");
            System.out.println("");
            remove3();
        } else {
            System.out.println("The item is not available.");
        }
    }

    private static void remove4() {
        System.out.print("Item Name: ");
        item = scn.nextLine();

        if (item.equalsIgnoreCase("Chicken Chop")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Fish & Chip")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Fries")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Nuggget")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Hotdog")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));

        } else if (item.equalsIgnoreCase("Pasta")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Pizza")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Cocacola")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("100 Plus ")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Sprite")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(10).item + " " + df.format(itemList.get(10).price));
        } else if (item.equalsIgnoreCase("Mineral Water")) {
            System.out.println("The " + item + " is removed.");
            System.out.println("");
            System.out.println("Item\t\t\tPrice(RM)");
            System.out.println("****\t\t\t*********");
            System.out.println(itemList.get(0).item + " " + df.format(itemList.get(0).price));
            System.out.println(itemList.get(1).item + " " + df.format(itemList.get(1).price));
            System.out.println(itemList.get(2).item + " " + df.format(itemList.get(2).price));
            System.out.println(itemList.get(3).item + " " + df.format(itemList.get(3).price));
            System.out.println(itemList.get(4).item + " " + df.format(itemList.get(4).price));
            System.out.println(itemList.get(5).item + " " + df.format(itemList.get(5).price));
            System.out.println(itemList.get(6).item + " " + df.format(itemList.get(6).price));
            System.out.println(itemList.get(7).item + " " + df.format(itemList.get(7).price));
            System.out.println(itemList.get(8).item + " " + df.format(itemList.get(8).price));
            System.out.println(itemList.get(9).item + " " + df.format(itemList.get(9).price));
        } else if (item.isEmpty()) {
            System.out.println("Please enter again.");
            System.out.println("");
            remove4();
        } else {
            System.out.println("The item is not available.");
        }
    }

}
